﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Crafts", "zhTW" )

if not L then return end

L["Broadcast my profession links to guild at logon"] = "上線時在公會廣播我的專業聯繫"
L["BROADCAST_PROFS_DISABLED"] = "將沒有任何發送. 禁用此選項大大降低公會頻道的網絡通信流量."
L["BROADCAST_PROFS_ENABLED"] = "你角色已知的專業鏈接將在你上線的5秒後發送到公會頻道."
L["BROADCAST_PROFS_TITLE"] = "廣播專業聯繫"
L["Professions"] = "專業技能"
L["Secondary Skills"] = "次要技能"

