local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore", "deDE" )

if not L then return end

L["Disabled"] = "Deaktiviert"
L["Enabled"] = "Aktiviert"
L["Memory used for %d |4character:characters;:"] = "Verwendeter Speicher für %d |4charakter:charaktere;:"

