﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Auctions", "koKR" )

if not L then return end


